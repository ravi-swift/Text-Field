//
//  ViewController.swift
//  textfield
//
//  Created by Rp on 28/11/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet var textfield : UITextField!
    
    let textfieldSecound = UITextField()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        textfield.placeholder = "First Name"
        textfield.backgroundColor = UIColor.yellow
        textfield.textColor = UIColor.blue
        textfield.font = UIFont.systemFont(ofSize: 25)
        textfield.keyboardType = UIKeyboardType.default
        textfield.autocorrectionType = .default
        textfield.tintColor = UIColor.blue
        textfield.layer.borderWidth = 5
        textfield.layer.borderColor = UIColor.red.cgColor
        textfield.layer.cornerRadius = 10
        textfield.attributedPlaceholder = NSAttributedString.init(string: textfield.placeholder!, attributes: [NSAttributedStringKey.foregroundColor:UIColor.red, NSAttributedStringKey.font:UIFont.systemFont(ofSize: 20)])
             // change place holder color use attributedplaceholder
        
        let leftview = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 10, height: 0))
        textfield.leftView = leftview
        textfield.leftViewMode = .always
        
        textfieldSecound.delegate = self
        textfieldSecound.frame = CGRect.init(x: 20, y: 150, width: UIScreen.main.bounds.size.width-40, height: 30)
        textfieldSecound.textColor = UIColor.red
        textfieldSecound.backgroundColor = UIColor.white
        textfieldSecound.font = UIFont.systemFont(ofSize: 25)
        textfieldSecound.placeholder = "Enter Password"
        textfieldSecound.tintColor = UIColor.red
        textfieldSecound.layer.borderWidth  = 2
        textfieldSecound.layer.borderColor = UIColor.blue.cgColor
        textfieldSecound.layer.cornerRadius = 10
        textfieldSecound.isSecureTextEntry = true  // use for securities
        view.addSubview(textfieldSecound)
        
        let leftviewSecound = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 10, height: 0))
        textfieldSecound.leftView = leftviewSecound
        textfieldSecound.leftViewMode = .always
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

